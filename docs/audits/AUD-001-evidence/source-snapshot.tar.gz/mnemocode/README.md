# MnemoCode

Offline reversible representations and optional date-shift masking for English BIP39 mnemonics.

MnemoCode provides a TypeScript library and the `mnemocode` command-line program. It can represent a valid mnemonic directly as BIP39 indexes, a continuous Unicode code-point stream, RGB colors, or compact Private Use Unicode color symbols. Its date-shift mode is based on [Seedshift](https://github.com/mifunetoshiro/Seedshift), but transforms mnemonic entropy and derives a fresh checksum so that the stored result is always another valid BIP39 phrase.

These representations can make a written mnemonic less immediately recognizable. Date shifting adds a memorized or separately recorded reversible mask. Neither feature replaces authenticated, memory-hard encryption or a strong BIP39 passphrase.

## Install and run

```bash
npm install
npm run build
node dist/mnemocode.js --help
```

For development, run commands without building first:

```bash
npm run dev -- encode --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" --dates 10-07-1963
```

After a global or local package installation, the same commands are available as `mnemocode`.

## Transformation modes

`--mode direct` validates the English BIP39 mnemonic and represents its existing indexes without changing them. It needs no dates. This is the mode for displaying the current phrase as colors or as the Unicode code-point stream derived through the corresponding Traditional Chinese BIP39 entries.

`--mode seedshift` is MnemoCode's checksum-valid modification of Seedshift. Encoding and decoding require the same dates. Commands that contain `--dates` but omit `--mode` select this mode; a command without dates defaults to `direct`.

`--mode seedshift-legacy` reproduces the original Seedshift whole-word transformation exactly. Its shifted output normally has an invalid BIP39 checksum. Keep this mode for existing Seedshift records and interoperability tests.

Legacy encoding always checks the shifted phrase immediately. If its checksum is already valid, MnemoCode says so. Otherwise it prints, without asking an interactive question, the checksum-valid final word and the complete optional replacement phrase. The exact legacy output remains the primary result unless `--legacy-valid-last-word` is supplied:

```bash
mnemocode encode --mode seedshift-legacy --legacy-valid-last-word \
  --mnemonic "..." --dates 23-09-2026 --format 1
```

That option preserves the first words and the entropy portion of the shifted final word, then derives the appropriate checksum bits. Like the original Seedshift option, replacing the final word discards the original shifted last-word value. MnemoCode records this as `seedshift-legacy-valid`, so decoding enumerates every possible checksum-valid original: 128 candidates for 12 words, 64 for 15, 32 for 18, 16 for 21, and 8 for 24. Each candidate is printed with its empty-passphrase BIP32 master fingerprint. Compare that fingerprint or stronger wallet evidence to select the intended phrase.

### How checksum-valid Seedshift works

BIP39 appends a checksum to the entropy and divides the combined bit stream into 11-bit word indexes. Every word except the last therefore consists entirely of entropy bits. The last word contains the remaining entropy bits followed by the checksum:

| Words | Entropy bits in final word | Checksum bits | Tail modulus |
| ---: | ---: | ---: | ---: |
| 12 | 7 | 4 | 128 |
| 15 | 6 | 5 | 64 |
| 18 | 5 | 6 | 32 |
| 21 | 4 | 7 | 16 |
| 24 | 3 | 8 | 8 |

MnemoCode validates the source mnemonic and removes its checksum to obtain the original entropy. Every complete 11-bit entropy block is shifted modulo 2048 using Seedshift's sorted year/month/day sequence. The remaining entropy tail contains `r` bits and is shifted separately modulo $2^r$, the number of values representable by those bits. Thus the modulus is 128 when `r = 7` for a 12-word mnemonic, 64 for 15 words, 32 for 18 words, 16 for 21 words, and 8 when `r = 3` for a 24-word mnemonic. MnemoCode joins the transformed entropy blocks and computes a fresh BIP39 checksum. No checksum bits are shifted, preserved, or guessed.

Decoding validates the container, removes its derived checksum, subtracts the same shifts from the complete blocks and entropy tail, and computes the original checksum from the recovered entropy. Modular addition and subtraction are inverses, so the correct dates always recover the original mnemonic without iteration, collision handling, or separately stored bits.

For example, the public 12-word phrase `abandon` repeated eleven times followed by `about` has a seven-bit final entropy tail of `0000000`. With the single date `23-09-2026`, the final scheduled shift is 23, so the tail becomes `(0 + 23) mod 128 = 23`, or `0010111`. After the other entropy blocks are shifted and a new four-bit checksum is calculated, the container is:

```text
wool abuse actual wool abuse actual wool abuse actual wool abuse congress
```

On recovery, `(23 - 23) mod 128 = 0`; the original zero entropy and its derived checksum produce the original final word `about`.

The author considers this behavior preferable for MnemoCode because the stored representation is an ordinary checksum-valid mnemonic and no original final word or checksum needs to be remembered separately. The tradeoff is deliberate: every accepted date combination produces a valid BIP39 mnemonic (not necessarily a distinct one), in the same way that every BIP39 passphrase produces a wallet. The checksum detects damage to the stored container but cannot identify the intended dates. Record the original BIP32 master fingerprint, or use a known address or public key, if an explicit recovery check is required.

### Formal construction

Let `n` be the mnemonic word count, where `n` is one of `12, 15, 18, 21, 24`. For BIP39,

$$
\mathrm{ENT}=\frac{32n}{3},\qquad
\mathrm{CS}=\frac{\mathrm{ENT}}{32}=\frac{n}{3}.
$$

Define the number of entropy bits carried by the final word as

$$
r=\mathrm{ENT}-11(n-1)=11-\mathrm{CS}=\mathrm{ENT}\bmod 11.
$$

Thus `r` is respectively `7, 6, 5, 4, 3`. Interpret the entropy as

$$
x=(x_1,\ldots,x_{n-1},t)
\in G_n=(\mathbb Z_{2048})^{n-1}\times\mathbb Z_{2^r},
$$

where every `x_i` is one complete 11-bit entropy block and `t` is the `r`-bit entropy tail. The cardinality is

$$
|G_n|=2048^{n-1}2^r
=2^{11(n-1)+r}
=2^{\mathrm{ENT}},
$$

so this decomposition covers the entire BIP39 entropy space exactly. In particular, a 24-word mnemonic uses

$$
G_{24}=(\mathbb Z_{2048})^{23}\times\mathbb Z_8.
$$

After sorting the dates and expanding them into the repeating year/month/day schedule, let

$$
s=(s_1,\ldots,s_n)
$$

be the resulting fixed shift vector. MnemoCode applies the group translation

$$
T_s(x_1,\ldots,x_{n-1},t)=
\left(
(x_1+s_1)\bmod 2048,\ldots,
(x_{n-1}+s_{n-1})\bmod 2048,
(t+s_n)\bmod 2^r
\right).
$$

Its inverse is subtraction in the same product group:

$$
T_s^{-1}(y_1,\ldots,y_{n-1},u)=
\left(
(y_1-s_1)\bmod 2048,\ldots,
(y_{n-1}-s_{n-1})\bmod 2048,
(u-s_n)\bmod 2^r
\right).
$$

Therefore `T_s` is a bijection for every fixed date-derived vector `s`; no search or probabilistic success condition is involved.

Let the BIP39 checksum function be

$$
c(e)=\operatorname{MSB}_{\mathrm{CS}}(\operatorname{SHA256}(e)),
$$

and let `B_n(e)` append `c(e)` to the entropy and split the result into `n` 11-bit word indexes. `B_n` is a bijection between the `2^ENT` entropy values and the set of checksum-valid `n`-word BIP39 mnemonics. The complete MnemoCode transformation on valid mnemonics is therefore

$$
F_s=B_n\circ T_s\circ B_n^{-1},
$$

with inverse

$$
F_s^{-1}=B_n\circ T_s^{-1}\circ B_n^{-1}.
$$

This proves three properties directly: every valid input has exactly one output, every output is a checksum-valid BIP39 mnemonic, and the original is recovered exactly with the same dates. For 24 words, the final component is shifted modulo `8` specifically because it contains `3` entropy bits and `2^3 = 8` possible values.

This algebraic bijection is a statement about correctness and reversibility, not cryptographic strength. A fixed modular translation derived from memorable dates is not a keyed pseudorandom permutation and does not turn Seedshift into authenticated encryption.

## Secret input styles

The ordinary input style places the mnemonic and, for `seedshift`, dates directly in the command. It is convenient for public test vectors, but real secrets can remain in shell history and process arguments:

```bash
node dist/mnemocode.js encode \
  --mode seedshift \
  --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" \
  --dates 23-09-2026 08-08-1988 07-11-1951 \
  --format 3
```

On Linux, `--ask-secrets` privately prompts first for the mnemonic and then for one space-separated date list. Neither value appears in the command line:

```bash
node dist/mnemocode.js encode --mode seedshift --ask-secrets --format 3
```

Enter the dates at the second prompt as one line, for example `23-09-2026 08-08-1988 07-11-1951`.
The same input style is available for recovery: `node dist/mnemocode.js decode --mode seedshift --ask-secrets` privately asks for the encoded record and then the date list. `recover-date --ask-secrets` privately asks for the record and one date list containing exactly one unknown component. In `direct` mode, `--ask-secrets` asks only for the mnemonic or encoded record because there are no dates. Raw representations are detected automatically when the content has one unambiguous format; `--format` remains available as an explicit override.

## Commands

```bash
# Represent an ordinary valid English BIP39 mnemonic without changing its indexes.
mnemocode encode --mode direct --mnemonic "..." --format 3

# Apply checksum-valid Seedshift and represent the resulting valid mnemonic.
mnemocode encode --mode seedshift --mnemonic "..." --dates 10-07-1963 31-01-4489

# Reproduce an original Seedshift record when compatibility is required.
mnemocode encode --mode seedshift-legacy --mnemonic "..." --dates 10-07-1963 31-01-4489

# Store the optional checksum-valid legacy replacement.
mnemocode encode --mode seedshift-legacy --legacy-valid-last-word \
  --mnemonic "..." --dates 10-07-1963 31-01-4489 --output legacy-valid.txt

# Enumerate original candidates; the MNC1 header selects the recovery profile.
mnemocode decode --input-file legacy-valid.txt --dates 10-07-1963 31-01-4489

# Save the continuous Unicode code-point stream as a text file.
mnemocode encode --mode seedshift --mnemonic "..." --dates 10-07-1963 31-01-4489 --format 3 --output encoded-unicode.txt

# Recover a legacy raw value. Supply the mode because raw records have no header.
# Its Unicode representation is detected automatically.
mnemocode decode --mode seedshift-legacy --input "5BF65B57..." --dates 10-07-1963 31-01-4489

# Recover candidates when one component of one date is unknown.
mnemocode recover-date --input "5BF65B57..." --dates ??-07-1963 31-01-4489 \
  --master-fingerprint YOUR_FINGERPRINT

# Keep both the record and partly forgotten dates out of process arguments.
mnemocode recover-date --ask-secrets

# Look up one English/index/Unicode correspondence, or print the whole table.
mnemocode table --word abandon
mnemocode table --index 1
mnemocode table --unicode 5BF6
mnemocode table --all
```

Supported encoded forms are:

| `--format` | Recorded input representation for `decode` and `recover-date` |
| --- | --- |
| `english` / `1` | English BIP39 words; shifted only in `seedshift` mode |
| `indexes` / `2` | Seedshift-compatible 1-based indexes from 1 through 2048 |
| `unicode` / `3` | Four-digit Unicode code points obtained from the Traditional Chinese BIP39 characters at the represented indexes. Codes may be separated by whitespace or written as one continuous string. |
| `colors` / `5` | CSS RGB codes such as `#01AB63`. Codes may be separated, concatenated with their `#` prefixes, or supplied as one continuous `RRGGBB` stream. The 12- and 24-word forms are compatible with BIP39Colors; MnemoCode additionally supports the standard 15-, 18-, and 21-word BIP39 lengths. |
| `colors-unicode` / `6` | The same color data encoded losslessly as two MnemoCode Private Use Unicode symbols per CSS RGB value. It supports all five standard BIP39 lengths. |

`colors-unicode` does not use the Traditional Chinese mapping from format 3. It first creates the exact reversible RGB values from format 5, then represents each 24-bit RGB value with two code points from Unicode's Private Use Area. Those code points have no standardized public meaning: MnemoCode defines their conversion back to `#RRGGBB`. A font without suitable Private Use glyphs may display boxes or blank symbols, but the underlying code points remain intact. The format conceals the visible hex notation; it is an encoding, not encryption.

For `decode` and `recover-date`, `--format` is normally optional. MnemoCode tries every strict representation parser and accepts automatic detection only when exactly one format produces a complete 12-, 15-, 18-, 21-, or 24-word record. If it cannot make a unique choice, an interactive terminal asks for the recorded format; a non-interactive script must pass `--format` so it never guesses. An explicit `--format` always takes priority for raw input. An `MNC1` record includes its format, so a conflicting `--format` value is rejected.

## Complete encode and decode examples

These examples deliberately use the public BIP39 test mnemonic `abandon ... about`. Terminal output remains the raw representation. `--output` writes a self-describing `MNC1` record; matching decode commands recognize its mode and format automatically.

`encode` always displays the selected representation and fingerprints in the terminal. Use `--output PATH` to save a copy as well. The saved `MNC1` record includes the mode and format needed for recovery. The `--output` option requires a file path.

```bash
# 1: shifted English BIP39 words
node dist/mnemocode.js encode \
  --mode seedshift \
  --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" \
  --dates 23-09-2026 08-08-1988 07-11-1951 \
  --format 1 --output shifted-english.txt
node dist/mnemocode.js decode --input-file shifted-english.txt \
  --dates 23-09-2026 08-08-1988 07-11-1951

# 2: shifted 1-based BIP39 indexes
node dist/mnemocode.js encode \
  --mode seedshift \
  --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" \
  --dates 23-09-2026 08-08-1988 07-11-1951 \
  --format 2 --output shifted-indexes.txt
node dist/mnemocode.js decode --input-file shifted-indexes.txt \
  --dates 23-09-2026 08-08-1988 07-11-1951

# 3: continuous Unicode code-point stream
node dist/mnemocode.js encode \
  --mode seedshift \
  --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" \
  --dates 23-09-2026 08-08-1988 07-11-1951 \
  --format 3 --output shifted-unicode.txt
node dist/mnemocode.js decode --input-file shifted-unicode.txt \
  --dates 23-09-2026 08-08-1988 07-11-1951

# 5: BIP39Colors-compatible RGB hexadecimal codes
node dist/mnemocode.js encode \
  --mode seedshift \
  --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" \
  --dates 23-09-2026 08-08-1988 07-11-1951 \
  --format 5 --output shifted-colors.txt
node dist/mnemocode.js decode --input-file shifted-colors.txt \
  --dates 23-09-2026 08-08-1988 07-11-1951

# 6: lossless Private Use Unicode encoding of the RGB codes
node dist/mnemocode.js encode \
  --mode seedshift \
  --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" \
  --dates 23-09-2026 08-08-1988 07-11-1951 \
  --format 6 --output shifted-color-unicode.txt
node dist/mnemocode.js decode --input-file shifted-color-unicode.txt \
  --dates 23-09-2026 08-08-1988 07-11-1951
```

The same formats work without date shifting. These commands represent the mnemonic's current indexes directly and recover the same mnemonic without dates:

```bash
# Direct Unicode representation.
node dist/mnemocode.js encode --mode direct \
  --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" \
  --format 3 --output direct-unicode.txt
node dist/mnemocode.js decode --mode direct --input-file direct-unicode.txt --format 3

# Direct color representation.
node dist/mnemocode.js encode --mode direct \
  --mnemonic "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about" \
  --format 5 --output direct-colors.txt
node dist/mnemocode.js decode --mode direct --input-file direct-colors.txt --format 5

```

`encode` displays English BIP39 words by default. In `seedshift` mode the result is a checksum-valid shifted mnemonic; `seedshift-legacy` applies the original whole-word transformation; in `direct` mode the words are unchanged. `--format 3` (`unicode`) maps every represented index to the character at the same position in the Traditional Chinese BIP39 list, converts that character to its four-digit Unicode code point, and concatenates all code points without spaces. The intermediate Chinese characters are never printed. `--format 5` (`colors`) and `--format 6` (`colors-unicode`) select color representations. For decoding, use the same mode and format that were recorded.

After encoding, the CLI prints the BIP32 master fingerprint of the original mnemonic and of the checksum-valid container. These fingerprints assume the default empty BIP39 passphrase and are public 32-bit identifiers, not secret authentication values. Legacy Seedshift output may not be a valid BIP39 mnemonic, so only its original fingerprint is shown.

MnemoCode supports every ordinary BIP39 length: 12, 15, 18, 21, and 24 words. The original Seedshift command line supports every one except 21 words; that length is a MnemoCode extension. The date limit is one date per three words, so the respective limits are 4, 5, 6, 7, and 8 dates.

## Terminal cards and QR

Sixteen approved templates are installed; see the full template table below.
The original photographic business designs choose compatible default employers:

| Template | Visual | Employer sector |
| --- | --- | --- |
| `business-architect` (1) | Architectural skyline and coloured contact tabs | Architecture and interiors |
| `business-it` (2) | Processor photography and coloured contact tabs | IT |
| `business-estate` (3) | Glass skyscrapers and rounded accent ribbons | Property |

`--format` selects the encoded representation, `--template` selects the visual design,
`--page-size` selects the sheet size, `--orientation portrait|landscape` selects its orientation,
and `--pdf PATH` selects the destination.

- `--page-size a6` (default for business and glass collections): one landscape 148 × 105 mm page holding the entire collection. Personal text is miniature; this is a catalogue sheet, not full-size business cards.
- `--page-size a4`: portrait 210 × 297 mm print sheets, eight **90 × 50 mm** cards per portrait page (six per landscape page) as a collection of full-size samples. For the seven single-reference business designs and `business-mixed`, twelve words need eight cards / one front page; 24 words need 16 cards / two front pages. Glass designs group several references per card; material designs use a sample grid. Enabling QR can add a reverse page. Print at **100% / actual size**, without fit-to-page scaling. There are no cutting marks or printer bleed: this is a sample collection, not a cutting sheet.

Optional personal fields: `--card-name`, `--card-role`, `--card-company`,
`--card-email`, `--card-phone` (property consultant), `--card-website`, `--card-location`. Each supplied field replaces only
that field. A company, compatible role and full name are selected once per export
from the approved pools: 20 employers, 60 Latin-script names and 26 roles.
The complete pools are listed in [Card identity presets](docs/card-identities.md).
Ten roles, including sales, management and business analysis, are available across
sectors. IT roles include DevOps Engineer and Senior DevOps Engineer. A mixed
collection and all SSKR members reuse the same identity.

Unspecified email and website fields use `contact@<company-name>.com` and
`<company-name>.com`, with the employer name reduced to a DNS label. These are
decorative defaults, not verified domains or contact details. Explicit contact
fields always override them. The default phone remains `+44 20 7946 0281` and
location is `International`. Personal
fields never change the encoded data or the QR payload. Names must use Latin letters (spaces, apostrophes and hyphens are allowed); unsupported glyphs and text that cannot fit are
reported instead of silently truncating or printing missing characters.

```bash
# All installed designs in one PDF; public test mnemonic and demonstration dates.
node dist/mnemocode.js preview --all --words 24 --page-size a6 --pdf previews-a6.pdf
node dist/mnemocode.js preview --all --words 24 --page-size a4 --pdf previews-a4.pdf

# Preview the very same renderer with your own display details.
node dist/mnemocode.js preview --template business-it --words 24 \
  --card-name "Alex Morgan" --card-role "Software Engineer" \
  --card-email "alex@example.com" --page-size a6 --pdf my-preview.pdf

# Actual export. Hidden input requests the mnemonic and dates.
node dist/mnemocode.js encode --mode seedshift --ask-secrets --format 5 \
  --template business-architect --page-size a4 \
  --card-name "Alex Morgan" --card-email "alex@example.com" --pdf cards.pdf

node dist/mnemocode.js preview --list
```

### Individual business cards

Use `--cards-dir PATH` to save one PDF per sample or reference group. Business and
glass fragments default to **90 × 50 mm**; material fragments default to **85.6 × 54 mm**.
All templates accept `--page-size` to change that size and support the
same optional personal details. There is no archive dependency. Choose a new
folder: MnemoCode refuses to mix new cards into an existing directory.

```bash
node dist/mnemocode.js encode --mode seedshift --ask-secrets --format 5 \
  --template business-it --card-name "John Smith" \
  --card-company "VECTOR SYSTEMS" --card-role "Software Engineer" \
  --card-email "john@example.com" --cards-dir ./my-it-cards

# Public demonstration, without entering a mnemonic:
node dist/mnemocode.js preview --template business-it --words 24 \
  --cards-dir ./sample-it-cards
```

Files are named `01-ABCDEF.pdf`, `02-123456.pdf`, and so on. Each file includes
only its own exact reference or, for glass templates, its group of four, six or
eight references. No individual fragment contains a whole-collection QR or other
fragments’ references. All cards are rendered before the finished directory is published.
This is **not Shamir secret sharing**: every reference is needed to recover the
mnemonic; the individual cards reveal portions of the encoded representation.

`--cards-dir` can also use the common page-size and orientation options. Optional collection outputs must be outside the individual-card directory.
For individual previews, select one template per folder; `preview --all` still
combines all collection designs into one PDF when used with `--pdf`.

`preview --words` accepts 12, 15, 18, 21 or 24 (default 12). Every preview uses
public zero-entropy test words and Bitcoin milestone dates, never a real secret.
The IT and architect backgrounds are compact 900 × 500 indexed PNGs.
The property consultant background is a shared 720 × 400 indexed PNG (199,704 bytes);
all its colour variants reuse that asset. Text and reference codes remain separately typeset, and the collection
QR remains vector-based.

Preview and ordinary export share the renderer and local photographic assets:
there is no simplified preview/export substitution or network image generation
at runtime. The decorative accent loosely follows the code's hue; **the exact
six-digit `Ref.` is the recovery data**, not the photographed colour. The references sit below the samples. All references must be
retained. QR is off by default. With `--card-qr`, business and material collections
use one complete-representation QR on a reverse page. Glass cards can use fragment
QRs inline when the physical module size fits, otherwise a collection QR is placed
on a reverse page. Individual files carry only their own reference or group.
No QR contains dates, personal details, fingerprints or MNC1 metadata.

`--title TEXT` overrides the business collection title; material and glass headings use the studio and sheet-copy fields. Dated-card APIs and `--events`
remain available, but no new Unicode dated-card design has been approved yet.
The business-card designs accept formats 5 and 6 only; they do not silently
replace a dated card. Terminal encoding and standalone QR remain available for
all representations. Every installed design supports the wallet page size.

The `colors` format implements the documented BIP39Colors packing exactly for 12 words (eight CSS colors) and 24 words (sixteen CSS colors). MnemoCode extends the same reversible packing to 15, 18, and 21 words, using 10, 12, and 14 colors respectively. The codes are the recovery data. They can be reordered, but every code must be retained. `colors-unicode` stores those same codes using two Private Use Area Unicode scalars per color. It is a MnemoCode format, not a Unicode color standard; it is intended for a compact reversible text record, not for display in a particular font.

```bash
# Print the precise codes and colour cards in the terminal.
mnemocode encode --mode seedshift --mnemonic "..." --dates 10-07-1963 --format 5 --cards

# Save the raw selected representation in a PNG QR code.
mnemocode encode --mode seedshift --mnemonic "..." --dates 10-07-1963 --format 5 \
  --qr my-palette-qr.png

# Read the PNG QR locally; --format 5 is selected automatically.
mnemocode decode --mode seedshift --qr-file my-palette-qr.png --dates 10-07-1963
```

The QR code contains only the raw representation selected by `--format`. It contains no `MNC1` header, mode name, format name, dates, labels, password, or wallet metadata. `mnemocode decode --qr-file my-palette-qr.png --dates ...` reads the PNG locally, detects the representation from its contents, and selects checksum-valid Seedshift because dates were supplied. A scanned or transcribed value works the same way; `--format` remains available as an explicit override.

## Versioned records and legacy compatibility

Only a text file explicitly requested with `--output PATH` uses `MNC1:<mode>:<format>:<payload>`. This public prefix prevents a future recovery session from having to remember whether the file used `direct`, checksum-valid `seedshift`, exact `seedshift-legacy`, or the lossy `seedshift-legacy-valid` replacement profile; it also identifies the representation and container revision. Dates remain separate because they are the Seedshift secret or memorized input. If explicit `--mode` or `--format` flags contradict a versioned record, MnemoCode stops instead of silently using the wrong decoder. QR images deliberately contain only the raw representation and never this descriptive header.

Existing files, pasted strings, and QR codes without a header remain supported. Supply their original `--mode` and `--format` exactly as before.

QR image parsing is a local CLI adapter. The library decoders also accept the text payload directly.

## Date recovery helper

`recover-date` accepts exactly one incomplete pattern such as `??-07-1963`, `10-??-1963`, or `10-07-????`. It tries real calendar dates and performs complete recovery for each one.

For `seedshift-legacy`, it can retain candidates whose recovered mnemonic has a valid BIP39 checksum, although a 4–8-bit checksum is only a weak filter. For checksum-valid `seedshift` and `seedshift-legacy-valid`, every candidate date can produce checksum-valid mnemonics, so `recover-date` requires independent evidence such as `--master-fingerprint`, `--bitcoin-address`, `--compressed-public-key`, or an xpub. The helper does not alter the encoded phrase or silently replace its final word.

## Exact local recovery checks

`recover-date` can also retain only candidates that match one independently known Bitcoin identifier. All checks are local; the command does not contact a wallet, a node, or a block explorer.

```bash
# A known first native-SegWit receiving address: m/84'/0'/0'/0/0.
mnemocode recover-date --input "..." --format 3 --dates ??-07-1963 \
  --bitcoin-address bc1q... --bitcoin-profile native-segwit

# A master or account public extended key. Standard and SLIP-132 public forms are accepted:
# xpub, ypub, zpub, Ypub, Zpub; testnet tpub, upub, vpub, Upub, Vpub.
mnemocode recover-date --input "..." --format 3 --dates ??-07-1963 \
  --account-xpub zpub... --bitcoin-profile native-segwit

# A 33-byte compressed public key at the selected BIP44/49/84/86 path.
mnemocode recover-date --input "..." --format 3 --dates ??-07-1963 \
  --compressed-public-key 02... --bitcoin-profile taproot --account 0 --branch 0 --index 0
```

The address and public-key forms require the derivation location. Defaults are mainnet, account `0`, receiving branch `0`, and index `0`; set `--network testnet`, `--account`, `--branch`, or `--index` when necessary. `--bitcoin-profile auto` tries the four single-key BIP44, BIP49, BIP84, and BIP86 profiles at that one location.

`--master-xpub` and `--account-xpub` are public recovery evidence. A `--master-fingerprint` is accepted for convenience, but contains only 32 bits and is only a filter. `--wif-file PATH` compares a WIF at the selected path and is exact, but a WIF is private spending material: put it in a locally protected file, never a shell command or issue report. If the wallet uses a BIP39 passphrase, supply it from `--bip39-passphrase-file PATH`; that file is likewise secret.

## Self-tests and public vectors

Before `encode`, `decode`, `recover-date`, `table`, `preview`, or an SSKR command processes input, MnemoCode runs a small deterministic core self-test. It checks the exact length and SHA-256 digest of the English BIP39 word list, direct conversion, the checksum-valid Seedshift vector, the original Seedshift compatibility vector, reverse recovery, and BIP39 checksum validity. A failure stops before mnemonic data is processed:

```text
CRITICAL: MnemoCode core self-test failed.
No mnemonic data was processed.
```

The normal self-test contains no filesystem or QR work and is intended to add only a small startup cost. Run the extended check before using a newly built or copied installation:

```bash
node dist/mnemocode.js self-test
```

The extended command verifies all five standard mnemonic lengths, all five representations, direct, checksum-valid Seedshift and legacy Seedshift round trips, deterministic date sorting, the versioned public vector file, QR PNG creation and local decoding, SSKR integrity and its independent grouped vector, and representative A6 exports covering every artwork family, embedded font and enabled QR. It prints each completed group, timing, and a final `PASS` line. The public interoperability vectors are stored in [`vectors/mnemocode-v1.json`](vectors/mnemocode-v1.json); they contain only well-known public test mnemonics.

## Compatibility and safety notes

- Dates use `DD-MM-YYYY` and are sorted from oldest to newest before use; their typed order does not matter. The older `YYYY-MM-DD` spelling remains accepted for compatibility.
- Years from `0001` through `9999` are accepted. Shifts remain modulo 2048, so years separated by 2048 yield the same per-date year shift.
- Format 3 internally maps each shifted index through the Traditional Chinese BIP39 list and records only the resulting concatenated Unicode code points. The intermediate characters are never printed by the CLI. This is obfuscation, not authenticated encryption.
- Checksum-valid `seedshift` always produces a valid BIP39 mnemonic by transforming entropy and recomputing the checksum. `seedshift-legacy` normally does not. Do not manually replace the final word of a legacy record: doing so loses information unless extra recovery data is saved.
- A valid checksum in the new mode confirms the stored container, not the dates. Different dates can produce the same shift schedule; other schedules can recover a different but still valid mnemonic. Compare the displayed original master fingerprint or other known wallet evidence when confirmation is needed.
- MnemoCode does not collect, transmit, or log mnemonic data. Shell history, process arguments, terminal scrollback, swap, crash reports, clipboard managers, and malware can still expose secrets. Use `--ask-secrets` for a real mnemonic and its dates.
- Perform real encoding and recovery only on a computer disconnected from every network. A freshly booted, trusted LiveCD or read-only Live USB environment is preferable because it avoids the ordinary installed operating system and leaves less persistent state. Disable Wi-Fi and Bluetooth before entering secrets, do not use cloud terminals or remote shells, and shut the temporary system down after securely saving the intended output.
- The encoded record, its QR, and its required dates must still be handled as sensitive recovery material. Obfuscation protects mainly against casual recognition; it does not replace memory-hard authenticated encryption.
- A matching address proves recovery only for the explicitly selected network, BIP purpose, account, branch, and index. It does not search wallet accounts or query balances.

## Library use

The TypeScript library exposes the same transformations used by the CLI:

```ts
import { encodeMnemonic, decodeInput, masterFingerprint, parseDate } from 'mnemocode';

const dates = ['10-07-1963', '31-01-4489'].map(parseDate);
const encoded = encodeMnemonic(mnemonic, dates);
const recovered = decodeInput(encoded.unicodeCodePoints.join(''), 'unicode', dates);
console.log(masterFingerprint(mnemonic));

// Direct representation without dates.
import { representMnemonic, decodeInputDirect, formatEncoded } from 'mnemocode';
const direct = representMnemonic(mnemonic);
const directUnicode = formatEncoded(direct, 'unicode');
const sameMnemonic = decodeInputDirect(directUnicode, 'unicode');
```

`@scure/bip39` supplies both word lists. Library exports are listed in `src/index.ts`; SSKR has a separate `mnemocode/sskr` entry point.

Runtime and development dependency versions are exact in `package.json`; `pnpm-lock.yaml` records integrity hashes for repeatable installation. The package remains `private` while distribution is limited to the repository and local CLI builds.

## Continuous integration

GitHub Actions installs from the frozen lockfile, checks TypeScript, builds the CLI and library, runs the fast test suite, and audits dependencies for high-severity advisories. Tests cover direct and Seedshift round trips across all five BIP39 word counts and every representation, versioned and legacy CLI records, hidden input, automatic and explicit self-tests, date recovery, QR input, and local Bitcoin recovery evidence.

## Provenance and license

MnemoCode is an independent TypeScript implementation of a checksum-valid date-shift mode derived from Seedshift, with an explicit legacy compatibility mode and additional CLI recovery and representation features. It is not affiliated with, endorsed by, or an official fork of Seedshift or BIP39Colors.

The MnemoCode source is MIT licensed. `NOTICE` attributes compatible formats to [Seedshift by mifunetoshiro](https://github.com/mifunetoshiro/Seedshift), which is MIT licensed, and [BIP39Colors by EnteroPositivo](https://github.com/EnteroPositivo/bip39colors), which is CC BY 4.0. `THIRD_PARTY_NOTICES.md` records dependencies and word-list provenance.

## SSKR threshold shares

`encode --sskr`, `sskr-combine`, and `sskr-export` support N-of-M SSKR, including 2-of-3. Choose one QR card per share, an A6/A4 color collection per share, or separate numbered color cards forming each share. Existing card profiles are supported. See [SSKR commands, formats and recovery](docs/SSKR.md).

SSKR is an optional output stage: `encode --sskr --threshold 2 --shares 3`.
`--format` still selects the encoded mnemonic display; `--share-format ur|colors`
selects the share display. `--pdf` collects every share into one PDF, while
`--cards-dir` creates separate member files. Both may be requested together.
`sskr-split` remains available as a compatibility alias.

## Current template and export matrix

All sixteen templates support `--page-size a4|a6|wallet|business`, portrait/landscape,
collection PDF output and individual `--cards-dir` files. Wallet means 85.6 x 54 mm;
business means 90 x 50 mm. Business collections default to A6; material selections
default to wallet size. When `--card-qr` is enabled, small business collections and material selections use the
reverse for their QR. Individual fragments contain only their own reference and no
whole-collection QR. All fragments of an ordinary representation are required. For SSKR, the full
member folder reconstructs one share; then the configured threshold of shares is required.

| ID | Design |
| --- | --- |
| business-architect | Architecture |
| business-it | IT |
| business-estate | Property consultant |
| business-diagonal | City photograph with diagonal accent |
| business-contact | Light contact blocks |
| business-curves | Layered dark curves |
| business-facets | Light geometric corners |
| business-mixed | One identity across the seven business designs |
| material-vehicle | Matte and satin vehicle wrap finishes |
| material-enclosure | Anodised enclosure finishes |
| material-tile | Bathroom tiles |
| material-switch | Switch finishes |
| material-kitchen | Kitchen material selection |
| business-glass-4in1 | Frosted glass, four ordered references per card |
| business-glass-6in1 | Compact glass, six ordered references per card |
| business-glass-8in1 | Compact glass, eight ordered references per card |

`business-mixed` also supports individual files: each reference gets the next design,
cycling after seven. The company, name and contacts stay identical. Material headings
use `--studio-name` for the issuing studio and `--card-name` for the recipient.
Both receive independently selected defaults when omitted.
Each photographic sample carries its actual finish name and the **exact** encoded Ref.
The nearest available realistic photographic finish is selected for appearance only;
it is not guaranteed to match the RGB value exactly and does not affect recovery.

```bash
node dist/mnemocode.js preview --all --words 24 --page-size wallet --pdf all-wallet-previews.pdf
node dist/mnemocode.js preview --template business-mixed --page-size business --cards-dir ./mixed-cards
node dist/mnemocode.js preview --template material-vehicle --studio-name "AURORA STUDIO" --card-name "John Smith" --pdf wrap-preview.pdf
```

### Four-, six- and eight-reference glass cards

`business-glass-4in1` groups four consecutive references into each 90 x 50 mm
card. A 12-word representation uses two cards; a 24-word representation uses
four. The final card can contain fewer references. Reference numbers preserve
order. QR is optional (`--card-qr`); each ordinary card QR contains ONLY that card’s references, not the
whole phrase. Concatenate all card references in numbered order for decoding.
With SSKR `--card-layout individual`, each member folder must remain complete;
`--card-layout qr` stores one full member in its QR.

The additional `business-glass-6in1` and `business-glass-8in1` templates group six or eight references per card. For a 24-word mnemonic (16 ordinary RGB references), they produce three or two individual cards respectively. The final group may be incomplete; no padding references are printed. SSKR uses its own transport length and groups each member separately.

With `--card-qr`, compact glass variants use inline QR only when its module size fits at the actual printed dimensions. Smaller A6 collections use one reverse QR rather than shrinking individual QR codes below the layout limit. PDF and PNG/JPEG exports share these decisions.


All templates support optional image output using the same PDF renderer:
`--images-dir NEW_FOLDER` exports collection pages as PNG by default;
`--image-format jpg` selects JPEG. For separate cards use `--cards-dir NEW_FOLDER
--image-format png`. Images are rendered locally at 300 dpi by the optional
Poppler `pdftoppm` executable. No new npm dependency or online service is used.
PDF export does not require Poppler. PNG preserves text and QR edges losslessly;
JPEG uses quality 90. Physical translucency is simulated by the fixed glass artwork.

### Collection-sheet identity

The design studio on a collection sheet is independent of the employer inside its business cards. One studio is selected from 37 deduplicated names, with independent choices from 30 print slogans, five subtitles and six footers. The selection is reused throughout one export, including all SSKR members and simultaneously saved formats. A separate identity selection chooses one employer, compatible role and Latin-script full name; automatic email and website labels follow that employer.

Use `--studio-name "Alder & Vale"` for the sheet studio and `--card-company "Your Company"` for the employer. `--card-slogan`, `--card-subtitle`, `--card-footer`, and `--card-reference-label` override optional copy; `-` hides an optional field. Omitted personal fields use the independently selected card identity described above.

QR is disabled on ordinary cards by default; add `--card-qr` when wanted. SSKR export defaults to `--card-layout collection` without QR; explicit `--card-layout qr` enables the complete-member QR. Individual SSKR fragments never receive a full-member QR; with `--card-qr`, only their own printed references are encoded.

## Source layout and review

See [module responsibilities](docs/ARCHITECTURE.md) and [review scope and verification](docs/REVIEW.md). Formatting uses the checked-in Prettier configuration. Formatting and compiler checks do not replace the full pre-release test run.
