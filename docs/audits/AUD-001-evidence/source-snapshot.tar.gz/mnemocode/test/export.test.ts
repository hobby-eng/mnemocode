import { describe, expect, it, vi } from 'vitest';
import { PDFDocument } from 'pdf-lib';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { renderCards, exportCards } from '../src/export/pdf.js';
import { cardTemplates, type CardContent, type CardTemplate } from '../src/export/templates.js';
import { parseArguments, values } from '../src/cli/arguments.js';
import { completeEventLabels } from '../src/cli/card-options.js';
import { parseDate } from '../src/core.js';

// Blank PDF fixture tests the export transport only. It is never a registered design.
async function fixture(pageCount = 1) {
  const doc = await PDFDocument.create();
  for (let i = 0; i < pageCount; i++) doc.addPage([100, 60]);
  return doc.save();
}
const content: CardContent = { kind: 'colors', colors: [], payload: 'public test' };

describe('export infrastructure', () => {
  it('ships sixteen approved templates with individual export', () => {
    expect(cardTemplates).toHaveLength(16);
    expect(new Set(cardTemplates.map((t) => t.id)).size).toBe(16);
    for (const template of cardTemplates) expect(template.renderIndividual).toBeTypeOf('function');
  });

  it('preserves an individual rendered PDF byte-for-byte in preview/export transport', async () => {
    const bytes = await fixture();
    const template: CardTemplate = {
      id: 'test-only',
      kind: 'colors',
      name: '',
      description: '',
      render: vi.fn(async () => bytes),
    };
    const jobs = [{ template, content }];
    expect(await renderCards(jobs)).toEqual(bytes);
    const directory = await mkdtemp(join(tmpdir(), 'mnemocode-export-'));
    try {
      const path = join(directory, 'test.pdf');
      await exportCards(jobs, path);
      expect(new Uint8Array(await readFile(path))).toEqual(bytes);
    } finally {
      await rm(directory, { recursive: true, force: true });
    }
    expect(template.render).toHaveBeenCalledWith(content);
  });

  it('merges all renderers into a single PDF with unchanged page dimensions', async () => {
    const template: CardTemplate = {
      id: 'test-only',
      kind: 'colors',
      name: '',
      description: '',
      render: () => fixture(),
    };
    const output = await PDFDocument.load(
      await renderCards([
        { template, content },
        { template, content },
      ]),
    );
    expect(output.getPageCount()).toBe(2);
    for (const page of output.getPages())
      expect(page.getSize()).toEqual({ width: 100, height: 60 });
  });

  it('rejects empty jobs and wrong card types, and preserves multi-page collections', async () => {
    const template: CardTemplate = {
      id: 'test-only',
      kind: 'colors',
      name: '',
      description: '',
      render: () => fixture(2),
    };
    await expect(renderCards([])).rejects.toThrow('No approved');
    expect(
      (
        await PDFDocument.load(
          await renderCards([
            { template, content },
            { template, content },
          ]),
        )
      ).getPageCount(),
    ).toBe(4);
    await expect(
      renderCards([{ template: { ...template, kind: 'unicode' }, content }]),
    ).rejects.toThrow('does not support');
  });

  it('keeps date and label lists in entered order and validates the number of labels', async () => {
    const args = parseArguments([
      '--dates',
      '23-09-2026',
      '08-08-1988',
      '--events',
      'Project review',
      'Birthday',
    ]);
    expect(values(args, 'date')).toEqual(['23-09-2026', '08-08-1988']);
    expect(values(args, 'event')).toEqual(['Project review', 'Birthday']);
    const dates = values(args, 'date').map(parseDate);
    expect(await completeEventLabels(dates, values(args, 'event'))).toEqual([
      'Project review',
      'Birthday',
    ]);
    await expect(completeEventLabels(dates, ['A', 'B', 'C'])).rejects.toThrow('exactly one');
    await expect(completeEventLabels(dates, ['A', ' '])).rejects.toThrow('must not be empty');
  });
});
