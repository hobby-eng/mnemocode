import { HDKey, type Versions } from '@scure/bip32';
import { mnemonicToSeedSync } from '@scure/bip39';
import { NETWORK, TEST_NETWORK, WIF, p2pkh, p2sh, p2tr, p2wpkh } from '@scure/btc-signer';

export type BitcoinNetworkName = 'mainnet' | 'testnet';
export type BitcoinProfile = 'legacy' | 'nested-segwit' | 'native-segwit' | 'taproot';
export const bitcoinProfiles: readonly BitcoinProfile[] = [
  'legacy',
  'nested-segwit',
  'native-segwit',
  'taproot',
];

export interface DerivationLocation {
  readonly network: BitcoinNetworkName;
  readonly account: number;
  readonly branch: number;
  readonly index: number;
}

export type BitcoinEvidence =
  | {
      readonly kind: 'address';
      readonly value: string;
      readonly profiles: readonly BitcoinProfile[];
      readonly location: DerivationLocation;
    }
  | {
      readonly kind: 'compressed-public-key';
      readonly value: string;
      readonly profiles: readonly BitcoinProfile[];
      readonly location: DerivationLocation;
    }
  | {
      readonly kind: 'wif';
      readonly value: string;
      readonly profiles: readonly BitcoinProfile[];
      readonly location: DerivationLocation;
    }
  | { readonly kind: 'master-xpub'; readonly value: string; readonly network: BitcoinNetworkName }
  | {
      readonly kind: 'account-xpub';
      readonly value: string;
      readonly profiles: readonly BitcoinProfile[];
      readonly location: DerivationLocation;
    }
  | {
      readonly kind: 'master-fingerprint';
      readonly value: string;
      readonly network: BitcoinNetworkName;
    };

export interface EvidenceMatch {
  readonly matched: boolean;
  readonly kind: BitcoinEvidence['kind'];
  readonly derived?: string;
  readonly path?: string;
  readonly warning?: string;
}

const mainnetVersions: Versions = { private: 0x0488ade4, public: 0x0488b21e };
const testnetVersions: Versions = { private: 0x04358394, public: 0x043587cf };

const extendedKeyVersions: Readonly<
  Record<string, { readonly versions: Versions; readonly network: BitcoinNetworkName }>
> = {
  xpub: { versions: mainnetVersions, network: 'mainnet' },
  ypub: { versions: { private: 0x049d7878, public: 0x049d7cb2 }, network: 'mainnet' },
  zpub: { versions: { private: 0x04b2430c, public: 0x04b24746 }, network: 'mainnet' },
  Ypub: { versions: { private: 0x0295b005, public: 0x0295b43f }, network: 'mainnet' },
  Zpub: { versions: { private: 0x02aa7a99, public: 0x02aa7ed3 }, network: 'mainnet' },
  tpub: { versions: testnetVersions, network: 'testnet' },
  upub: { versions: { private: 0x044a4e28, public: 0x044a5262 }, network: 'testnet' },
  vpub: { versions: { private: 0x045f18bc, public: 0x045f1cf6 }, network: 'testnet' },
  Upub: { versions: { private: 0x024285b5, public: 0x024289ef }, network: 'testnet' },
  Vpub: { versions: { private: 0x02575048, public: 0x02575483 }, network: 'testnet' },
};

function equalBytes(left: Uint8Array | null, right: Uint8Array | null): boolean {
  if (left === null || right === null || left.length !== right.length) return false;
  let different = 0;
  for (let index = 0; index < left.length; index += 1) different |= left[index]! ^ right[index]!;
  return different === 0;
}

function hex(bytes: Uint8Array): string {
  return Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('');
}

function parseHex(value: string): Uint8Array {
  const normalized = value.trim().toLowerCase();
  if (!/^[0-9a-f]{66}$/.test(normalized))
    throw new Error(
      'A compressed public key must be exactly 33 bytes encoded as 66 hexadecimal characters.',
    );
  const bytes = new Uint8Array(33);
  for (let index = 0; index < bytes.length; index += 1)
    bytes[index] = Number.parseInt(normalized.slice(index * 2, index * 2 + 2), 16);
  if (bytes[0] !== 0x02 && bytes[0] !== 0x03)
    throw new Error('A compressed public key must start with 02 or 03.');
  return bytes;
}

function assertNetwork(network: BitcoinNetworkName): void {
  if (network !== 'mainnet' && network !== 'testnet') {
    throw new Error('Bitcoin network must be mainnet or testnet.');
  }
}

function assertLocation(location: DerivationLocation): void {
  assertNetwork(location.network);
  for (const name of ['account', 'branch', 'index'] as const) {
    const value = location[name];
    if (!Number.isSafeInteger(value) || value < 0 || value >= 0x80000000) {
      throw new Error(`${name} must be an integer from 0 through 2147483647.`);
    }
  }
}

function coinType(network: BitcoinNetworkName): number {
  return network === 'mainnet' ? 0 : 1;
}

const derivationPurposes: Readonly<Record<BitcoinProfile, number>> = {
  legacy: 44,
  'nested-segwit': 49,
  'native-segwit': 84,
  taproot: 86,
};

function purpose(profile: BitcoinProfile): number {
  return derivationPurposes[profile];
}

function path(profile: BitcoinProfile, location: DerivationLocation): string {
  return `m/${purpose(profile)}'/${coinType(location.network)}'/${location.account}'/${location.branch}/${location.index}`;
}

function accountPath(profile: BitcoinProfile, location: DerivationLocation): string {
  return `m/${purpose(profile)}'/${coinType(location.network)}'/${location.account}'`;
}

function paymentAddress(
  profile: BitcoinProfile,
  publicKey: Uint8Array,
  network: BitcoinNetworkName,
): string {
  const parameters = network === 'mainnet' ? NETWORK : TEST_NETWORK;
  if (profile === 'legacy') return p2pkh(publicKey, parameters).address;
  if (profile === 'nested-segwit') return p2sh(p2wpkh(publicKey, parameters), parameters).address;
  if (profile === 'native-segwit') return p2wpkh(publicKey, parameters).address;
  return p2tr(publicKey.slice(1), undefined, parameters).address;
}

function extendedMetadata(value: string): {
  readonly versions: Versions;
  readonly network: BitcoinNetworkName;
} {
  const prefix = value.trim().slice(0, 4);
  const metadata = extendedKeyVersions[prefix];
  if (metadata === undefined)
    throw new Error(
      'Unsupported extended-key prefix. Supported public forms include xpub, ypub, zpub, Ypub, Zpub, tpub, upub, vpub, Upub, and Vpub.',
    );
  return metadata;
}

function sameExtendedKey(left: HDKey, right: HDKey): boolean {
  return (
    left.depth === right.depth &&
    left.index === right.index &&
    left.parentFingerprint === right.parentFingerprint &&
    equalBytes(left.publicKey, right.publicKey) &&
    equalBytes(left.chainCode, right.chainCode)
  );
}

function rootForMnemonic(mnemonic: string, passphrase: string, network: BitcoinNetworkName): HDKey {
  assertNetwork(network);
  const seed = mnemonicToSeedSync(mnemonic, passphrase);
  try {
    return HDKey.fromMasterSeed(seed, network === 'mainnet' ? mainnetVersions : testnetVersions);
  } finally {
    // This function owns the temporary byte buffer; caller-owned mnemonic strings remain unchanged.
    seed.fill(0);
  }
}

/** Returns the standard four-byte BIP32 master fingerprint as lowercase hexadecimal. */
export function masterFingerprint(mnemonic: string, passphrase = ''): string {
  const root = rootForMnemonic(mnemonic, passphrase, 'mainnet');
  try {
    return root.fingerprint.toString(16).padStart(8, '0');
  } finally {
    root.wipePrivateData();
  }
}

function candidates(profiles: readonly BitcoinProfile[]): readonly BitcoinProfile[] {
  if (profiles.length === 0) {
    throw new Error('At least one Bitcoin address profile must be selected.');
  }
  if (profiles.some((profile) => !bitcoinProfiles.includes(profile))) {
    throw new Error('Unknown Bitcoin address profile.');
  }
  return profiles;
}

type LocatedEvidence = Exclude<BitcoinEvidence, { kind: 'master-xpub' | 'master-fingerprint' }>;

function matchingWif(
  node: HDKey,
  evidence: Extract<BitcoinEvidence, { kind: 'wif' }>,
): string | undefined {
  const derivedKey = node.privateKey;
  if (derivedKey === null) throw new Error('Unable to derive the private key for WIF comparison.');
  const network = evidence.location.network === 'mainnet' ? NETWORK : TEST_NETWORK;
  const coder = WIF(network);
  const expected = coder.decode(evidence.value.trim());
  try {
    return equalBytes(derivedKey, expected) ? coder.encode(derivedKey) : undefined;
  } finally {
    expected.fill(0);
  }
}

function matchingAccountKey(
  node: HDKey,
  evidence: Extract<BitcoinEvidence, { kind: 'account-xpub' }>,
): string | undefined {
  const metadata = extendedMetadata(evidence.value);
  if (metadata.network !== evidence.location.network) {
    throw new Error('The extended-key prefix and --network disagree.');
  }
  const expected = HDKey.fromExtendedKey(evidence.value.trim(), metadata.versions);
  try {
    return sameExtendedKey(node, expected) ? node.publicExtendedKey : undefined;
  } finally {
    expected.wipePrivateData();
  }
}

function matchDerivedNode(
  node: HDKey,
  evidence: LocatedEvidence,
  profile: BitcoinProfile,
): string | undefined {
  if (node.publicKey === null) throw new Error('Unable to derive the public key.');
  switch (evidence.kind) {
    case 'address': {
      const derived = paymentAddress(profile, node.publicKey, evidence.location.network);
      return derived === evidence.value.trim() ? derived : undefined;
    }
    case 'compressed-public-key': {
      const matches = equalBytes(node.publicKey, parseHex(evidence.value));
      return matches ? hex(node.publicKey) : undefined;
    }
    case 'wif':
      return matchingWif(node, evidence);
    case 'account-xpub':
      return matchingAccountKey(node, evidence);
  }
}

/** Compares a recovered mnemonic locally. It does not contact a node or a block explorer. */
export function matchBitcoinEvidence(
  mnemonic: string,
  evidence: BitcoinEvidence,
  passphrase = '',
): EvidenceMatch {
  if (evidence.kind === 'master-xpub') {
    const metadata = extendedMetadata(evidence.value);
    if (metadata.network !== evidence.network)
      throw new Error('The extended-key prefix and --network disagree.');
    const expected = HDKey.fromExtendedKey(evidence.value.trim(), metadata.versions);
    const root = rootForMnemonic(mnemonic, passphrase, evidence.network);
    try {
      return {
        matched: sameExtendedKey(root, expected),
        kind: evidence.kind,
        derived: root.publicExtendedKey,
        path: 'm',
      };
    } finally {
      root.wipePrivateData();
      expected.wipePrivateData();
    }
  }

  if (evidence.kind === 'master-fingerprint') {
    if (!/^[0-9a-fA-F]{8}$/.test(evidence.value))
      throw new Error('A master fingerprint must be eight hexadecimal characters.');
    const root = rootForMnemonic(mnemonic, passphrase, evidence.network);
    try {
      const derived = root.fingerprint.toString(16).padStart(8, '0');
      return {
        matched: derived === evidence.value.toLowerCase(),
        kind: evidence.kind,
        derived,
        path: 'm',
        warning: 'A master fingerprint is only 32 bits and is a filter, not proof of recovery.',
      };
    } finally {
      root.wipePrivateData();
    }
  }

  assertLocation(evidence.location);
  const profiles = candidates(evidence.profiles);
  const root = rootForMnemonic(mnemonic, passphrase, evidence.location.network);
  try {
    for (const profile of profiles) {
      const derivationPath =
        evidence.kind === 'account-xpub'
          ? accountPath(profile, evidence.location)
          : path(profile, evidence.location);
      const node = root.derive(derivationPath);
      try {
        const derived = matchDerivedNode(node, evidence, profile);
        if (derived !== undefined) {
          return { matched: true, kind: evidence.kind, derived, path: derivationPath };
        }
      } finally {
        node.wipePrivateData();
      }
    }
    return { matched: false, kind: evidence.kind };
  } finally {
    root.wipePrivateData();
  }
}
