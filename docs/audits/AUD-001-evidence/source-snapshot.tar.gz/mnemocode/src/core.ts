/** Stable public API. Implementations are grouped by responsibility in core/. */
export {
  BIP39_WORD_COUNTS,
  type Bip39WordCount,
  type OutputFormat,
  type DateShiftDate,
  type EncodedResult,
  type DecodedResult,
  type MappingRow,
  type DatePattern,
} from './core/types.js';
export { unicodeHex, mappingRow, allMappingRows } from './core/words.js';
export {
  maximumDates,
  isLeapYear,
  daysInMonth,
  parseDate,
  formatDate,
  sortDates,
  deriveShifts,
  parseDatePattern,
  expandDatePattern,
} from './core/dates.js';
export {
  indexesToColors,
  parseColors,
  colorsToIndexes,
  colorsToUnicode,
  unicodeToColors,
} from './core/colors.js';
export { parseInput, detectInputFormats, formatEncoded } from './core/representations.js';
export {
  encodeMnemonic,
  encodeMnemonicLegacy,
  legacyChecksumValidResult,
  representMnemonic,
  decodeIndexes,
  decodeIndexesLegacy,
  decodeIndexesLegacyValid,
  decodeInput,
  decodeInputLegacy,
  decodeInputDirect,
} from './core/seedshift.js';
