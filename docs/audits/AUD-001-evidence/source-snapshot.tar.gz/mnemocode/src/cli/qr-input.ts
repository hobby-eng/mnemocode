import { readFile } from 'node:fs/promises';
import jsQRModule from 'jsqr';
import { PNG } from 'pngjs';

/** Reads a QR code from a PNG file saved by the local palette exporter. */
export async function decodeQrPngFile(path: string): Promise<string> {
  const image = PNG.sync.read(await readFile(path));
  // jsQR ships a legacy CommonJS wrapper whose NodeNext import type is exposed
  // as a namespace despite its runtime default export being the scanner.
  const scan = jsQRModule as unknown as (
    data: Uint8ClampedArray,
    width: number,
    height: number,
    options: { inversionAttempts: 'attemptBoth' },
  ) => { data: string } | null;
  const decoded = scan(
    new Uint8ClampedArray(image.data.buffer, image.data.byteOffset, image.data.byteLength),
    image.width,
    image.height,
    { inversionAttempts: 'attemptBoth' },
  );
  if (decoded === null) throw new Error('No readable QR code was found in the PNG file.');
  return decoded.data;
}
