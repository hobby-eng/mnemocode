import { constants } from 'node:fs';
import { access, lstat, stat } from 'node:fs/promises';
import { dirname, isAbsolute, relative, resolve } from 'node:path';
import { value, values, type ParsedArguments } from './arguments.js';

function contains(parent: string, child: string): boolean {
  const relation = relative(resolve(parent), resolve(child));
  return relation === '' || (relation.split(/[\\/]/u)[0] !== '..' && !isAbsolute(relation));
}

/** Files and folders must not shadow one another or overwrite an input. */
export function validateOutputPaths(args: ParsedArguments): void {
  const outputs = ['images-dir', 'cards-dir', 'pdf', 'output', 'qr'].flatMap((key) => {
    const path = value(args, key);
    return path === undefined ? [] : [{ key, path }];
  });
  for (const [index, left] of outputs.entries()) {
    for (const right of outputs.slice(index + 1)) {
      if (contains(left.path, right.path) || contains(right.path, left.path))
        throw new Error(
          `--${left.key} and --${right.key} must use separate, non-overlapping paths.`,
        );
    }
    for (const key of ['mnemonic-file', 'input-file', 'share-file', 'share-qr']) {
      for (const source of values(args, key)) {
        if (source !== '-' && (contains(left.path, source) || contains(source, left.path)))
          throw new Error(`--${left.key} must not overlap --${key}.`);
      }
    }
  }
}

/** This is a preflight; the writer still enforces exclusive or atomic publication. */
export async function preflightFileDestination(
  path: string,
  allowOverwrite: boolean,
): Promise<void> {
  if (!path.trim() || path === '-')
    throw new Error('File export requires a new file path. Terminal output is always enabled.');
  try {
    const existing = await lstat(path);
    if (!allowOverwrite) throw new Error('The output file already exists. Choose a new path.');
    if (existing.isDirectory()) throw new Error('The output path must be a file, not a directory.');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
  }
  const parent = dirname(resolve(path));
  if (!(await stat(parent)).isDirectory())
    throw new Error('The output parent must be a directory.');
  await access(parent, constants.W_OK);
}
