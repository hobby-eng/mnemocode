# Review notes

## Legacy last-word compatibility

`decodeIndexesLegacyValid` currently searches all checksum-valid original
last words after reversing the preceding words. This supports historical records
whose last word was replaced arbitrarily, including replacements made outside
MnemoCode.

MnemoCode's own `legacyChecksumValidResult` changes only checksum bits and retains
the shifted entropy prefix of the last word. For records known to have been made
by that specific operation, the retained prefix could narrow the candidate set.
The current recovery function does not assume that provenance: narrowing it
silently would exclude possible originals from older, arbitrary replacements.
Independent recovery evidence remains necessary when more than one candidate is
returned. A future strict recovery variant should be explicit and versioned.

## Readability update, September 2026

TypeScript source and tests were formatted with Prettier 3.9.8. No runtime
formatter dependency was added. Generated/vendor code and its integrity hashes
were excluded. Rustfmt was not available; the Rust bridge was not rewritten.

Before changing QR and presentation behavior, four public rendering fixtures
(12-word A6, 24-word A4, individual business card and SSKR QR card) were captured.
The extracted business renderer, layout helpers and document-scoped artwork cache
produced exactly the same pixels on all five pages at 144 dpi. Later presentation
and QR changes intentionally alter those pages. `scripts/business-goldens.mjs`
and `scripts/compare-business-goldens.py` support manual comparisons; they do not
run on normal CLI startup.

The review also removed secret values from malformed-input errors, made ordinary
PDF replacement private and atomic, and made WASM initialization consume the same
buffer whose integrity was checked. This is a bounded implementation review, not
an independent security audit. The full test suite was intentionally not run in
this update; focused export checks use public data only.

## Full-source readability pass, 2026-09-27

This pass reviewed the maintained TypeScript modules, CLI adapters, export paths,
renderers, helper scripts and included Rust boundary source. It is an implementation
review, not an independent cryptographic audit. No cryptographic dependency or
wire-format version changed.

Changes made:

- Split `core.ts` into seven responsibility-specific modules behind the same public
  facade. Named BIP39 bit widths, dictionary size and color-packing constants;
  documented entropy-tail/checksum handling and historical legacy compatibility.
- Split encode coordination, terminal reporting and exports. Added shared output
  destination checks. Invalid export combinations are rejected before hidden input.
- Text-record and standalone QR replacement now use private atomic writes (0600).
  Preview no longer skips requested collection output when individual output is
  also selected. SSKR render entry points validate layout and style consistently.
- Extracted material/glass geometry and rendering helpers, business typography
  profiles and sheet headings. Kept dimensions, layout numbers and artwork intact.
- Separated SSKR transport parsing, checksum, RGB conversion and set validation.
  Bitcoin evidence checks now reject invalid runtime network/profile/path values;
  owned seed and decoded-WIF buffers are cleared on exit where possible.
- Impossible partial calendar dates fail early. Invalid mapped Unicode errors
  report position instead of echoing the supplied data.
- Replaced parallel design/name arrays with a typed keyed registry. Reduced
  redundant non-null assertions in dated export and named rendering constants.
- The font-generation helper now retains Latin diacritics, combining marks and
  punctuation in addition to existing UI ranges. Bundled font bytes were not
  regenerated during this refactor.
- Updated help, README and SSKR documentation for the current registry, QR defaults,
  personal identity selection, page sizes and image output. Removed descriptions
  of unrelated applications; bridge notices now cover its own Cargo lockfile.

Focused verification used public data only:

- TypeScript compilation and Prettier formatting checks across 76 maintained
  source/test/script files. A before/after AST comparison preserved node kinds,
  identifiers and literal values; a second formatting check was clean.
- 380 old/new core comparisons: unchanged public exports, all five word lengths,
  three transformation modes, six output forms, legacy candidates and date patterns.
  Separate narrow checks cover invalid dates and Unicode error redaction.
- 38 SSKR transport comparisons against fixed public vectors and nine Bitcoin
  evidence comparisons. Invalid runtime network/profile values were rejected.
- Six fixed PDF fixtures, nine pages, pixel-identical at 144 dpi after the pure
  renderer refactor: 12-word A6, 24-word A4, individual business, SSKR QR, glass8
  and material. Fixture identities and copy are explicitly fixed.

The full Vitest suite and extended `mnemocode self-test` were not run in this pass,
following the current development restriction. The extended self-test's asset
coverage was expanded to mixed business, all material families and glass 4/6/8;
that new check itself still needs execution before release. No Rust compiler or
rustfmt run was performed. Pinned Rust, Cargo and generated JS/WASM bytes remain
unchanged; only their descriptive notices were scoped to this utility.

Remaining validation limits:

- PDF fixtures cover representative cases, not every template/size/input combination
  or every phone camera. Physical QR scan reliability needs print/device checks.
- PNG input is decoded synchronously without a dedicated file-size or pixel-count
  limit; unusually large local images can exhaust memory or block processing.
- Public-key evidence checks syntax but not full curve-point validity before
  comparison; malformed keys/addresses can become nonmatches rather than early
  errors. Date searches can therefore do unnecessary work for invalid evidence.
- Buffer clearing cannot guarantee erasure of JavaScript strings or temporary
  library copies. Source readability and successful compilation do not prove
  cryptographic security or eliminate the need for pre-release tests.
