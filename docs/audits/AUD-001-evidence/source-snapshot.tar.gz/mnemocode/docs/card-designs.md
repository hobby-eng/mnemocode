# Card designs and approval

Preview and export use the same renderer and local assets. Do not replace an approved visual with a simplified substitute. The installed registry contains sixteen approved templates; `preview --list` is the authoritative command for their IDs.

| ID | Design |
| --- | --- |
| business-architect | Architectural photography and editable business identity |
| business-it | IT processor photography and editable business identity |
| business-estate | Property consultant |
| business-diagonal | Diagonal city photography |
| business-contact | Light contact blocks |
| business-curves | Dark curved accents |
| business-facets | Light geometric accents |
| business-mixed | One business identity across the approved business designs |
| material-vehicle | Automotive finishes |
| material-enclosure | Device and enclosure finishes |
| material-tile | Tile and stone finishes |
| material-switch | Switch and hardware finishes |
| material-kitchen | Kitchen materials |
| business-glass-4in1 | Four ordered references per glass card |
| business-glass-6in1 | Six ordered references per compact glass card |
| business-glass-8in1 | Eight ordered references per compact glass card |

The original IDs, including the four-reference glass template, remain unchanged. Six- and eight-reference variants are additional choices. All templates support A4, A6, wallet and business sizes, individual files, PDF and optional local PNG/JPEG export. Artwork is decorative; printed references remain exact recovery data. Final groups may contain fewer references and are never filled with invented codes.

QR is disabled by default. With `--card-qr`, individual cards encode only their own printed references. Compact six- and eight-reference glass cards can place QR inline when its actual module size fits the physical card; a reduced A6 collection uses one reverse QR instead of unreadably small per-card codes. Other designs use the optional QR placement appropriate to their layout. Explicit SSKR `--card-layout qr` carries one complete member; fragment layout never carries a complete member inside an individual fragment.

The design-studio name and print copy belong to the collection sheet. They do not replace the employer, name, role or contacts inside business cards. One employer, compatible role and Latin-script full name are selected per export, independently of sheet branding and encoded data. Explicit personal fields override these defaults. The identity pool includes European and other international names; shared sales, management and business-analysis roles are available across sectors.

Retained title ideas:

- The Studio Edit
- The Psychology of Color
- Stunning Colors for Business Inspiration
- Travel-Inspired Shades
- Bold Tones for Bright Ideas
- Modern Shades for Meaningful Work
- Palette Notes for Creative Minds
- Thoughtful Tones for Modern Living
