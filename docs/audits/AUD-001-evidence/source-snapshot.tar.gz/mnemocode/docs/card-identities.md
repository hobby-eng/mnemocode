# Card identity presets

These employer and personal defaults are separate from the print-studio identity on collection sheets. One selection is reused for every page, individual file and SSKR member in an export. Explicit card fields override the defaults.

| Sector | Employers | Specialist roles |
| --- | --- | --- |
| it | Norvale Systems; Elmbridge Digital; Rillford Technologies; Ashmere Software; Fenwick Networks | Software Engineer; Solutions Architect; IT Consultant; Technical Director; DevOps Engineer; Senior DevOps Engineer |
| architecture | Alderwick Architecture; Larchfield Interiors; Merewood Design; Pennfold Spaces; Ashcombe Atelier | Architect; Interior Designer; Architectural Designer; Design Director |
| property | Bellmere Property; Oakstead Homes; Wrenford Estates; Alderbridge Realty; Merrow Property | Property Consultant; Real Estate Advisor; Property Manager |
| consulting | Halden Advisory; Norwick Consulting; Fieldmere Partners; Ashford Operations; Elmward Business Services | Strategy Consultant; Management Consultant; Operations Consultant |

## Shared roles

Sales Manager · Sales Consultant · Account Manager · Client Advisor · Business Consultant · Business Development Manager · Business Analyst · Senior Business Analyst · Operations Manager · Project Manager

## Full names

Names are selected as complete pairs and always use Latin script. Their inclusion does not assign a nationality or location to the card holder.

Alex Morgan · James Carter · Daniel Brooks · Oliver Reed · Henry Bennett · Thomas Hayes · William Foster · Ethan Clarke · Liam Parker · Samuel Ellis

Emma Collins · Olivia Bennett · Charlotte Reed · Amelia Brooks · Sophia Turner · Grace Morgan · Hannah Clarke · Emily Hayes · Alice Foster · Lucy Parker

Lukas Weber · Anna Fischer · Jonas Bauer · Clara Hoffmann · Julien Moreau · Camille Laurent · Nicolas Martin · Lea Dubois · Matteo Rossi · Giulia Conti

Luca Ferraro · Sofia Ricci · Javier Navarro · Lucia Romero · Ines Costa · Tiago Almeida · Pieter de Vries · Eva van Dijk · Lars Nyberg · Ingrid Berg

Mikkel Larsen · Aino Koskinen · Jakub Nowak · Zofia Kowalska · Tomas Novak · Petra Svobodova · Andrei Popescu · Elena Ionescu · Nikos Papadakis · Eleni Nikolaou

Emre Yilmaz · Selin Kaya · Hana Tanaka · Kenji Mori · Arjun Mehta · Priya Shah · Minjun Kim · Leila Mansour · Omar Haddad · Amina Diallo

## Contact fields

Automatic email and website text use a company-derived `.com` label. These decorative defaults are not verified contact details. Use `--card-email` and `--card-website` to provide real contacts. Phone and location remain explicit overrides or the existing generic defaults.
