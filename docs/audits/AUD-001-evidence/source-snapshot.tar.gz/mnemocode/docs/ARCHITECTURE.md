# Source layout

MnemoCode is a standalone offline CLI and TypeScript library. The CLI coordinates
input, transformations and output; renderers do not perform mnemonic or sharing
arithmetic. The public exports remain in `src/index.ts` and `src/sskr/index.ts`.

## Transformation layer

`src/core.ts` preserves the public API and re-exports implementations from:

| Module | Responsibility |
| --- | --- |
| `core/types.ts` | Public result types and supported word counts |
| `core/words.ts` | Word lists, index maps and mnemonic validation |
| `core/bits.ts` | Bit/byte conversion and modular arithmetic |
| `core/dates.ts` | Calendar validation, ordering, shift schedule and recovery patterns |
| `core/colors.ts` | BIP39Colors decimal packing and Private Use Unicode transport |
| `core/representations.ts` | Representation parsing, detection and formatting |
| `core/seedshift.ts` | Direct, checksum-valid and legacy transformations and inverses |

Core modules do not import CLI input, PDF renderers, image tools or SSKR runtime.
The final entropy chunk uses its own modulus; comments explain this invariant
beside both directions of the transformation. Legacy last-word recovery retains
its broad historical compatibility search.

`record.ts` parses the versioned MNC1 envelope. `bitcoin-evidence.ts` checks local
recovery evidence and derivation paths; it performs no network lookup.

## SSKR

`sskr/runtime.ts` loads pinned local WASM and supplies operating-system randomness.
`sskr/shares.ts` validates mnemonic/share inputs and invokes sharing/reconstruction.
`sskr/transport.ts` handles Bytewords, CBOR and ordered RGB records. Transport
constants name version bytes, CRC size, RGB grouping and zero-padding rules.
`sskr/self-test.ts` checks the independent public grouped vector.

The vendored Rust source and generated JS/WASM are kept separate from maintained
TypeScript. Formatting must not rewrite their pinned bytes. Dependency notices
are scoped to the included Cargo lockfile.

## CLI

`mnemocode.ts` dispatches commands and rejects unsupported flags. `cli/input.ts`
owns interactive/file input; `arguments.ts` and the option modules validate values.
`output-paths.ts` checks destinations before secret prompts. Writers still enforce
exclusive creation or private atomic replacement; preflight alone is not a lock.

`encode-command.ts` coordinates one transformation. `encode-report.ts` formats its
terminal result and `encode-export.ts` saves that result. `sskr-command.ts` handles
share input and export options. Recovery, previews and the table each have their
own command module. Terminal colour styling lives in `terminal.ts`.

## Cards and files

`export/templates.ts` is the installed design registry. Business, glass and material
families each have a renderer, layout module and artwork module. Layout dimensions
are millimetres; text helpers convert the established top-of-line-box convention
to PDF coordinates. Typography profiles and named geometry constants keep physical
choices near the drawing code.

`card-identities.ts` selects the employer, role and name; `card-copy.ts` independently
selects studio branding and sheet copy. Resolve these once at the export boundary
and forward the resolved values to every page and output format.

`card-qr.ts` draws vector modules and enforces the physical quiet-zone/module size.
Payload validation belongs before drawing. Individual fragments never silently
receive the complete collection or complete SSKR member.

`pdf.ts`, `individual-cards.ts` and `sskr-cards.ts` organize documents and destinations.
`image-export.ts` rasterizes those same PDFs with local Poppler. `private-file.ts`
replaces ordinary file exports through a private same-filesystem staging directory.
Artwork derived from a user's references is cached only for the current document;
shared caches contain fixed bundled artwork.

## Maintenance checks

Use the checked-in Prettier configuration for owned TypeScript and JavaScript
scripts, then `npm run check` and `npm run build`. The formatter is development
tooling, not a runtime dependency. Python helper scripts use conventional readable
formatting. Vendored/generated files are excluded from automatic rewriting.

For layout refactors, `scripts/business-goldens.mjs` creates fixed public fixtures
and `scripts/compare-business-goldens.py` compares their rasterized pages at 144 dpi.
Keep pure refactoring separate from intentional design changes. The comparison
covers those fixtures, not every possible design/input combination. Run the full
suite and extended CLI self-test before release; see the recorded review limits
in [REVIEW.md](REVIEW.md).
