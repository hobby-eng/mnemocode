# SSKR threshold sharing

MnemoCode creates and recovers Blockchain Commons SSKR shares locally, without network access. This provides threshold secret sharing. Optional Seedshift masking is a separate transformation applied before splitting. `encode --sskr` creates one group, with any **N of M** members required (`2 <= N <= M <= 16`). Recovery also accepts standard grouped SSKR records.

## Commands

Create three shares, requiring any two, and export one 90 x 50 mm QR business card per share:

```bash
node dist/mnemocode.js encode --sskr \
  --ask-secrets --threshold 2 --shares 3 \
  --template business-it --card-layout qr \
  --cards-dir ./sskr-qr-cards
```

The mnemonic must be valid English BIP39 (12/15/18/21/24 words). `--mnemonic "..."` and `--mnemonic-file PATH` / `-` remain available, but direct arguments can enter shell history and process listings. Use an offline computer, preferably a trusted live system. A BIP39 passphrase is not part of mnemonic entropy and is **not stored** in these shares.

To preserve the same share set across different layouts, save its standard UR records first:

```bash
node dist/mnemocode.js encode --sskr --ask-secrets \
  --threshold 2 --shares 3 --output ./shares.txt

node dist/mnemocode.js sskr-export --share-file ./shares.txt \
  --cards-dir ./sskr-a6 --card-layout collection \
  --template business-architect --page-size a6 --orientation portrait

node dist/mnemocode.js sskr-export --share-file ./shares.txt \
  --cards-dir ./sskr-individual --card-layout individual --template business-it
```

Terminal output is always enabled. `encode --sskr` retains ordinary `--format 1|2|3|5|6` for the transformed mnemonic shown in the terminal. `--share-format ur` is the default share representation; `--share-format colors` prints ordered share RGB codes instead. The compatibility command `sskr-split` and re-export command `sskr-export` use `--format ur|colors`. `--output` always stores standard UR, one share per line, and never overwrites an existing file. That file contains the **whole supplied set**, not a single share. You can combine `--output`, `--cards-dir`, and `--pdf NEW_FILE` in one invocation. The PDF collects all member pages in order, using the same share set as the individual files. The combined PDF contains the complete set, not a single share. Existing PDF files are refused. File output parents must already exist; the card directory is created automatically. Re-export reads existing shares without splitting the secret again; different copies of the same member never count as distinct shares.

## Layouts and profiles

| `--card-layout` | Output | What counts as one share |
| --- | --- | --- |
| `qr` | One document per member, using the selected page size and design | The complete-member QR |
| `collection` (default) | One document per member; page count depends on design, size and QR | All codes in that PDF, or its optional QR |
| `individual` | One folder per member, containing numbered fragments at the selected size | Every numbered card in that folder, in order |

Individual fragments have no QR by default and never contain a hidden copy of the whole share. If `--card-qr` is requested, their QR contains only the references printed on that fragment. Collection QR is disabled by default. Add `--card-qr` to a collection, or choose `--card-layout qr`, to include only the RGB representation of its own share. Each individual PDF in `--cards-dir` contains at most one member and never the original mnemonic. The optional combined `--pdf` explicitly contains all supplied members, one member per page or consecutive group of pages; there is no global QR. The directory contains the complete generated set: distribute members separately according to the chosen threshold. The printed collection reference identifies the SSKR set/group/member; the standard 16-bit set identifier is not a cryptographic authenticity guarantee.

All sixteen installed designs support SSKR: eight business collections, five material selections, and three glass variants. The full list is in [Card designs](card-designs.md). Use `preview --list` for the installed registry. Personal fields include `--card-name`, `--card-company`, `--card-role`, `--card-email`, `--card-phone`, `--card-website`, and `--card-location`; the visible contact fields depend on the design. `business-mixed` cycles the approved designs while keeping one identity across the collection. For QR shares it rotates the design between members; each QR still contains only its own share. Names use Latin letters. One employer, compatible role and full name are selected per export; explicit personal fields override them. `--page-size a4|a6|wallet|business` and `--orientation portrait|landscape` apply to every design and layout. Material selections include a QR reverse only when QR is explicitly enabled; individual fragments never include a complete-member QR. Folders are staged and published only after every PDF is written; existing destination folders are refused.

## Recovery

Supply complete shares, not individual colored fragments:

```bash
node dist/mnemocode.js sskr-combine --ask-secrets
# Enter complete shares separated by semicolons in the hidden prompt.

node dist/mnemocode.js sskr-combine \
  --share "ur:sskr/FIRST_COMPLETE_SHARE" \
  --share "ur:sskr/SECOND_COMPLETE_SHARE"

node dist/mnemocode.js sskr-combine --share-file ./selected-shares.txt
node dist/mnemocode.js sskr-combine --share-qr ./first.png --share-qr ./second.png
```

`--share`, `--share-file`, and `--share-qr` may repeat and be combined. Text files contain one complete share per non-empty line. PNG QR input uses the existing local decoder; PDF input is not supported by that decoder. Standard Compact UR, full Bytewords and MnemoCode SSKR RGB are detected per record and can be mixed. RGB codes may be separated by spaces or concatenated, with or without `#`; **their order matters**. Ordinary BIP39 format-5 colors are not SSKR colors.

Malformed CBOR, transport checksum errors, nonzero padding, duplicate member IDs, conflicting sets/group metadata, and insufficient thresholds are rejected. The native SSKR library performs reconstruction and its secret digest checks. A matching 16-bit identifier alone is insufficient to establish authenticity.

## Optional Seedshift

`encode --sskr --mode seedshift --dates ...` applies the checksum-valid transformation **before** splitting its entropy. Use the same `--mode seedshift --dates ...` with `sskr-combine` to undo it after reconstruction. With `--ask-secrets --mode seedshift`, both commands request dates through hidden input. Mode and dates are not embedded in a standard SSKR record: retain this recovery information separately. Other dates can recover a different checksum-valid BIP39 phrase; equivalent date-derived shift schedules recover the same phrase. Legacy Seedshift modes are rejected here. The default without dates is `direct`.

## Modules, provenance and checks

- `src/sskr/runtime.ts`: Node loader and cryptographic randomness; pinned local WASM and JS checksum verification.
- `src/sskr/shares.ts`: validated BIP39-to-SSKR creation and recovery.
- `src/sskr/transport.ts`: Bytewords/CBOR validation and reversible color representation.
- `src/export/sskr-cards.ts`: presentation of existing shares using the approved renderers.
- `src/cli/sskr-command.ts`: CLI input/output; no sharing arithmetic.

`vendor/sskr` contains the offline Rust/WASM bridge, Rust source, Cargo lockfile, hashes and notices. It uses `sskr 0.12.0` and `bc-shamir 0.13.0`. The bundled source, lockfile and generated binaries have pinned hashes in `vendor/sskr/integrity.json`. Dependency notices cover the SSKR bridge’s Cargo lockfile. The Rust upstream describes itself as Community Review; the external audit of the C implementation must not be represented as an audit of this Rust binary.

Before split/combine processes a mnemonic, a short SSKR self-check restores an independent official grouped vector and checks color transport. `mnemocode self-test` includes that check. `test/sskr.test.ts` adds all five entropy lengths, all 2-of-3 pairs, insufficient/duplicate/mixed members, corrupted/truncated/reordered colors, an official Bytewords vector and Seedshift composition. Development tests must be run before release; their presence alone does not mean this integration has been validated.

## SSKR RGB transport v1

Decode the single-part UR's minimal Bytewords body into bytes, retaining its four-byte CRC32. Prefix `A1` (format version) and the one-byte byte count. Append zero bytes only as needed to reach a multiple of three. Every three bytes are one exact `#RRGGBB` code, in order. On recovery, validate the exact encoded size and zero padding, remove the prefix/padding, verify the Bytewords CRC32 and SSKR CBOR structure, then reconstruct the standard UR. The QR uses these same space-separated RGB codes.

This transport is an encoding, not additional encryption. It retains all standard share metadata and preserves interoperability after conversion back to UR. There is no numeric BIP39 format alias for it.

## One encode operation with Seedshift and SSKR export

```bash
node dist/mnemocode.js encode --sskr --mode seedshift --ask-secrets \
  --format 3 --threshold 2 --shares 3 \
  --template business-estate --card-layout qr \
  --cards-dir ./property-shares --pdf ./property-shares.pdf
```

The input mnemonic is transformed once, then its transformed entropy is split once. Format 3 displays the transformed mnemonic's code points; share QR payloads use the ordered SSKR RGB transport with the member metadata required for reconstruction. Dates are not printed or embedded in share cards. Legacy modes are not supported. Without `--sskr`, threshold and share-layout flags are rejected rather than silently ignored.

Hidden input requires a controlling terminal. Prompts go directly to that terminal even if stdout or stderr is redirected, and typed secrets are not echoed. In a noninteractive process the command fails immediately instead of waiting for a system password agent.

## Published test vectors

`vectors/sskr-v1.json` publishes the independent [Blockchain Commons BCR-0011 grouped recovery vector](https://github.com/BlockchainCommons/Research/blob/master/papers/bcr-2020-011-sskr.md), its entropy, all eight UR members, tagged Bytewords, group thresholds, and valid/invalid quorum examples. The first member's exact transport bytes and RGB codes were derived independently from the published bytes using Python `zlib.crc32`; the startup self-check compares against that fixed RGB answer as well as the independent recovered entropy.

Five additional deterministic fixtures cover 128, 160, 192, 224, and 256-bit BIP39 entropy, exact share generation, and RGB transport. These fixtures were produced by the pinned bridge and are regression checks, **not independent validation of the cryptography**. Their fixed RNG seeds are public test data; production always calls the operating system's cryptographic randomness source.

The focused SSKR suite checks all 30 minimal quorums of the official two-group vector, every pair of each 2-of-3 fixture, the 16-of-16 boundary, insufficient/duplicate/mixed shares, malformed CBOR with recomputed transport checksums, reserved bits, padding, unknown versions, and tampered share data that reaches the native digest check.

All installed templates in `preview --list`, including material selections and the four-, six- and eight-reference glass designs, can export SSKR. Mixed designs cycle consistently within collections and across QR members. The same page-size options apply to every template.

## Optional PNG and JPEG export

All approved layouts use the same PDF renderer for image export. Add `--image-format png` or `--image-format jpg` to `--cards-dir` to save per-member cards or fragments as images instead of PDF. For multipage members, keep every numbered page together. `--images-dir NEW_FOLDER` exports the pages of the combined collection and defaults to PNG; this folder contains **all supplied shares**. PDF, separate-member output and combined-page images can be saved together using disjoint destinations.

```bash
node dist/mnemocode.js encode --sskr --ask-secrets \
  --threshold 2 --shares 3 --template business-glass-4in1 \
  --card-layout individual --cards-dir ./glass-share-images --image-format png

node dist/mnemocode.js sskr-export --share-file ./shares.txt \
  --template business-it --card-layout collection --page-size a6 \
  --images-dir ./share-pages --image-format jpg
```

Image rendering uses the optional local Poppler `pdftoppm` program at 300 dpi, with JPEG quality 90. It adds no npm dependency and makes no network requests. Missing renderer errors appear before a secret-input prompt. PNG preserves text and QR edges without lossy compression. Existing folders are refused, temporary files are cleaned up, and exported files use private permissions. Without image options, PDF behavior is unchanged. Glass templates retain their four-, six- or eight-reference grouping in every format; image conversion does not add a full-share QR to individual fragments.

## Studio identity and optional sheet copy

Collection sheets select one design-studio identity from a deduplicated pool of 37 studio names, with independently selected copy from 30 slogans, five subtitles and six footers. The selection is made once for the whole export, reused across all members, pages and simultaneously saved formats. It is unrelated to mnemonic data.

`--studio-name` overrides the design studio printed on collection sheets. `--card-company` is a separate employer field inside the business cards; the employer, compatible role and Latin-script full name are selected independently once per export. Automatic email and website labels follow the employer, and explicit personal fields take precedence. See [Card identity presets](card-identities.md).

Override sheet text with `--card-slogan`, `--card-subtitle`, `--card-footer`, and `--card-reference-label`. The default reference label is `Ref.`. Use `-` to hide any optional copy field. `--card-qr` is off by default. SSKR defaults to `--card-layout collection`; explicit `--card-layout qr` enables a complete-member QR without another flag. Individual SSKR fragments never contain a full-member QR; optional `--card-qr` encodes only that fragment’s own references.

## Compact glass fragments

`business-glass-4in1`, `business-glass-6in1`, and `business-glass-8in1` group four, six, or eight consecutive RGB references from **one member** on each card. Grouping restarts for every member; all fragments of that member remain necessary before it can count toward the SSKR quorum. The final card may contain fewer references. Filenames and printed ordering retain the complete sequence across PDF and image exports.

When explicitly enabled, an individual fragment QR contains only that fragment’s references. Six- and eight-reference cards place QR inline only if the physical module pitch fits; scaled collection layouts use one member QR on a reverse page. `--card-layout qr` is still the explicit complete-member QR mode.
